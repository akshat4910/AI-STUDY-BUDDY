"""AI Study Buddy - Flask server. Run: python app.py"""
from dotenv import load_dotenv
from flask import Flask, jsonify, request, send_from_directory
from pypdf import PdfReader

load_dotenv()

from backend import ai, quiz  # noqa: E402  (after load_dotenv)

app = Flask(__name__, static_folder="frontend", static_url_path="")


def body():
    data = request.get_json(silent=True) or {}
    chapter = (data.get("chapter") or "").strip()
    if len(chapter) < 50:
        raise ValueError("Paste or upload a longer chapter (at least 50 characters).")
    return data, chapter


def endpoint(fn):
    """Run fn(data, chapter) and return JSON, with friendly errors."""
    try:
        data, chapter = body()
        return jsonify(fn(data, chapter))
    except ValueError as e:
        return jsonify(error=str(e)), 400
    except Exception as e:  # API key missing, network, bad JSON from model...
        return jsonify(error=f"Something went wrong: {e}"), 500


@app.get("/")
def index():
    return send_from_directory("frontend", "index.html")


@app.post("/api/extract")
def extract():
    f = request.files.get("file")
    if not f:
        return jsonify(error="No file uploaded."), 400
    try:
        if f.filename.lower().endswith(".pdf"):
            text = "\n".join(p.extract_text() or "" for p in PdfReader(f).pages)
        else:
            text = f.read().decode("utf-8", errors="ignore")
    except Exception as e:
        return jsonify(error=f"Could not read file: {e}"), 400
    if not text.strip():
        return jsonify(error="No text found (scanned PDFs need OCR)."), 400
    return jsonify(text=text)


@app.post("/api/summary")
def summary():
    return endpoint(lambda d, c: {"summary": ai.summarize(c, d.get("level"))})


@app.post("/api/mcqs")
def mcqs():
    return endpoint(lambda d, c: {"questions": quiz.generate_mcqs(c, int(d.get("n", 5)), d.get("level"))})


@app.post("/api/short")
def short():
    return endpoint(lambda d, c: {"questions": quiz.generate_short_questions(c, 5, d.get("level"))})


@app.post("/api/flashcards")
def flashcards():
    return endpoint(lambda d, c: {"cards": quiz.generate_flashcards(c, 8, d.get("level"))})


@app.post("/api/ask")
def ask():
    return endpoint(lambda d, c: {"answer": ai.answer_question(c, d.get("question", ""))})


@app.post("/api/score")
def score():
    d = request.get_json(silent=True) or {}
    return jsonify(quiz.score_test(d.get("questions", []), d.get("answers", [])))


if __name__ == "__main__":
    app.run(debug=True, port=5000)
