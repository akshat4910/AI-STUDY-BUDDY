# AI Study Buddy

An AI-powered study assistant that helps students understand chapters,
generate quizzes and create flashcards.

## Features

- Paste notes or upload a PDF / .txt chapter
- Chapter summarization
- MCQ and short-answer question generation
- Flashcards (click to flip)
- AI Q&A grounded in your chapter
- Mini test with automatic scoring and explanations
- Level modes: Class 6-8, 9-10, 11-12, JEE

## Tech Stack

Python (Flask) - HTML/CSS/JavaScript - Anthropic Claude API - pypdf

## Architecture

```
Upload PDF / Paste notes -> /api/extract -> chapter text
chapter text -> backend/ai.py + backend/quiz.py -> Claude
Claude -> Summary | MCQs | Short Qs | Flashcards | Q&A -> Study dashboard
```

## Run it

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # add your ANTHROPIC_API_KEY
python app.py
```

Open http://localhost:5000

## Tests

```bash
pytest
```

## Limits

- Scanned (image-only) PDFs need OCR, which is not included yet.
- Only the first ~15,000 characters of a chapter are sent to the AI.

## Roadmap

- PDF to long-answer questions and printable test papers
- Saved scores and progress dashboard
- OCR for scanned textbooks
