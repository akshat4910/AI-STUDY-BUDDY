const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
let testQuestions = [];

async function api(path, payload) {
  const res = await fetch('/api/' + path, {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({chapter: $('#chapter').value, level: $('#level').value, ...payload}),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// Tabs
document.querySelectorAll('#tabs button').forEach(b => b.onclick = () => {
  document.querySelectorAll('#tabs button').forEach(x => x.classList.toggle('on', x === b));
  document.querySelectorAll('.tab').forEach(t => t.hidden = t.id !== b.dataset.tab);
});

// File upload
$('#file').onchange = async e => {
  const f = e.target.files[0]; if (!f) return;
  const fd = new FormData(); fd.append('file', f);
  const res = await fetch('/api/extract', {method: 'POST', body: fd});
  const data = await res.json();
  if (res.ok) $('#chapter').value = data.text; else alert(data.error);
};

// Run a tab's action with loading + error handling
function wire(id, run) {
  const tab = $('#' + id), btn = $('.go', tab), out = $('.out', tab);
  btn.onclick = async () => {
    btn.disabled = true; out.textContent = 'Working on it...';
    try { out.innerHTML = await run(out); } catch (e) { out.innerHTML = `<span class="err">${esc(e.message)}</span>`; }
    btn.disabled = false;
  };
}

wire('summary', async () => esc((await api('summary')).summary));

const mcqHTML = (qs, reveal) => qs.map((q, i) => `
  <div class="q"><b>${i + 1}. ${esc(q.question)}</b>
  ${q.options.map((o, j) => `<label><input type="radio" name="q${i}" value="${j}"> ${esc(o)}</label>`).join('')}
  ${reveal ? `<details><summary>Show answer</summary><span class="right">${esc(q.options[q.answer])}</span><br>${esc(q.explanation || '')}</details>` : ''}
  </div>`).join('');

wire('mcqs', async () => mcqHTML((await api('mcqs')).questions, true));

wire('short', async () => (await api('short')).questions.map((q, i) => `
  <div class="q"><b>${i + 1}. ${esc(q.question)}</b>
  <details><summary>Model answer</summary>${esc(q.model_answer)}</details></div>`).join(''));

wire('cards', async () => (await api('flashcards')).cards.map(c =>
  `<div class="flash" tabindex="0" role="button" data-f="${esc(c.front)}" data-b="${esc(c.back)}">${esc(c.front)}</div>`).join('')
  + '<p class="note">Click a card to flip it.</p>');

document.addEventListener('click', e => {
  const c = e.target.closest('.flash'); if (!c) return;
  const flipped = c.classList.toggle('flip');
  c.textContent = flipped ? c.dataset.b : c.dataset.f;
});

wire('ask', async () => esc((await api('ask', {question: $('#q').value})).answer));

wire('test', async out => {
  testQuestions = (await api('mcqs', {n: 5})).questions;
  setTimeout(() => {
    out.insertAdjacentHTML('beforeend', '<button id="submit">Submit test</button><div id="result"></div>');
    $('#submit').onclick = submitTest;
  });
  return mcqHTML(testQuestions, false);
});

async function submitTest() {
  const answers = testQuestions.map((_, i) => {
    const el = document.querySelector(`input[name="q${i}"]:checked`);
    return el ? +el.value : null;
  });
  const r = await (await fetch('/api/score', {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({questions: testQuestions, answers}),
  })).json();
  $('#result').innerHTML = `<p class="score">${r.score} / ${r.total} (${r.percent}%)</p>` +
    r.results.map((x, i) => `<p class="${x.correct ? 'right' : 'wrong'}">Q${i + 1}: ${x.correct ? 'Correct' : 'Wrong'}.
    Answer: ${esc(testQuestions[i].options[x.answer])}. ${esc(x.explanation)}</p>`).join('');
}
