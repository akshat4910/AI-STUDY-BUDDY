import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from backend.ai import parse_json
from backend.quiz import score_test

QS = [{"answer": 1, "explanation": "a"}, {"answer": 0, "explanation": "b"}]


def test_score_all_correct():
    assert score_test(QS, [1, 0])["percent"] == 100


def test_score_partial_and_skipped():
    r = score_test(QS, [1, None])
    assert (r["score"], r["total"], r["percent"]) == (1, 2, 50)


def test_empty_test():
    assert score_test([], [])["percent"] == 0


def test_parse_json_strips_fences():
    assert parse_json('```json\n[{"a": 1}]\n```') == [{"a": 1}]
