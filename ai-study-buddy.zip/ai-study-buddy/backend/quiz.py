"""Quiz, short-answer and flashcard generation + scoring."""
from .ai import MAX_CHARS, ask_json, level_text


def generate_mcqs(chapter, n=5, level="class9-10"):
    return ask_json(
        f"Write {n} multiple-choice questions for {level_text(level)} from the chapter. "
        'JSON: [{"question": str, "options": [4 strings], "answer": index 0-3, '
        f'"explanation": str}}]\n\nCHAPTER:\n{chapter[:MAX_CHARS]}'
    )


def generate_short_questions(chapter, n=5, level="class9-10"):
    return ask_json(
        f"Write {n} short-answer questions for {level_text(level)} from the chapter. "
        f'JSON: [{{"question": str, "model_answer": str}}]\n\nCHAPTER:\n{chapter[:MAX_CHARS]}'
    )


def generate_flashcards(chapter, n=8, level="class9-10"):
    return ask_json(
        f"Make {n} flashcards for {level_text(level)} from the chapter. "
        f'JSON: [{{"front": str, "back": str}}]\n\nCHAPTER:\n{chapter[:MAX_CHARS]}'
    )


def score_test(questions, answers):
    """questions: list of MCQ dicts; answers: list of chosen indexes (or None)."""
    results = []
    for i, q in enumerate(questions):
        chosen = answers[i] if i < len(answers) else None
        results.append({
            "correct": chosen == q["answer"],
            "chosen": chosen,
            "answer": q["answer"],
            "explanation": q.get("explanation", ""),
        })
    score = sum(r["correct"] for r in results)
    total = len(questions)
    pct = round(100 * score / total) if total else 0
    return {"score": score, "total": total, "percent": pct, "results": results}
