"""Thin wrapper around the Anthropic API."""
import json
import os
import re

from anthropic import Anthropic

MODEL = os.getenv("STUDY_BUDDY_MODEL", "claude-sonnet-5-5")
MAX_CHARS = 15000  # keep prompts reasonably small

LEVELS = {
    "class6-8": "a student in Class 6-8: simple words, short sentences",
    "class9-10": "a student in Class 9-10 (board exam style)",
    "class11-12": "a student in Class 11-12 (board exam style, deeper detail)",
    "jee": "a JEE aspirant: conceptual, application-based, tricky options",
}

_client = None


def client():
    global _client
    if _client is None:
        _client = Anthropic()  # reads ANTHROPIC_API_KEY
    return _client


def level_text(level):
    return LEVELS.get(level, LEVELS["class9-10"])


def ask(prompt, system="You are a clear, accurate study tutor.", max_tokens=2000):
    r = client().messages.create(
        model=MODEL,
        max_tokens=max_tokens,
        system=system,
        messages=[{"role": "user", "content": prompt}],
    )
    return "".join(b.text for b in r.content if b.type == "text")


def parse_json(text):
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip())
    return json.loads(text)


def ask_json(prompt, max_tokens=3000):
    return parse_json(ask(prompt + "\n\nReturn ONLY valid JSON. No other text.", max_tokens=max_tokens))


def summarize(chapter, level="class9-10"):
    return ask(
        f"Summarize this chapter for {level_text(level)}. Use short headings and bullet "
        f"points, and end with 'Key terms'.\n\nCHAPTER:\n{chapter[:MAX_CHARS]}"
    )


def answer_question(chapter, question):
    return ask(
        "Answer the student's question using ONLY the chapter below. If the chapter "
        f"doesn't cover it, say so.\n\nCHAPTER:\n{chapter[:MAX_CHARS]}\n\nQUESTION: {question}"
    )
